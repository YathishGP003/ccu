package a75f.io.dal;

/**
 * Created by rmatt on 7/19/2017.
 */

public class ScheduleCloudSync {

    //public static boolean saveSchedule(Schedule schedule) throws IOException {
      //  DataStore<Schedule> scheduleDataStore = DataStore.collection(Schedule.class.getSimpleName(), Schedule.class, StoreType.NETWORK, Globals.getInstance().getKinveyClient());

        /*scheduleDataStore.sync(new KinveySyncCallback<Schedule>() {
            @Override
            public void onSuccess(KinveyPushResponse kinveyPushResponse, KinveyPullResponse<Schedule> kinveyPullResponse) {

            }

            @Override
            public void onPullStarted() {

            }

            @Override
            public void onPushStarted() {

            }

            @Override
            public void onPullSuccess(KinveyPullResponse<Schedule> kinveyPullResponse) {

            }

            @Override
            public void onPushSuccess(KinveyPushResponse kinveyPushResponse) {

            }

            @Override
            public void onFailure(Throwable throwable) {

            }
        });*/
        //return true;
   // }

}
